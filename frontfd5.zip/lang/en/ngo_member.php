<?php
return [
    'ngo_member_list'=>'সাধারণ সদস্যদের তালিকা',
    'ngo_member'=>'সাধারণ সদস্য',
    'ngo_member_registration'=>'সাধারণ সদস্য নিবন্ধন',
    'name'=>'নাম',
    'designation'=>'উপাধি',
    'date_of_birth'=>'জন্ম তারিখ',
    'nid_no'=>'এনআইডি নম্বর',
    'mobile_no'=>'মোবাইল নম্বর',
    'fathers_name'=>'বাবার নাম',
    'present_address'=>'বর্তমান ঠিকানা',
    'permanent_address'=>'স্থায়ী ঠিকানা',
    'name_of_spouse'=>'স্বামী/স্ত্রীর নাম',
    'remarks'=>'মন্তব্য',

];

?>
