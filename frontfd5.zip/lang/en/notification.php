<?php
return [

    'success_one'=>'আপনি কি নিশ্চিত?',
	'success_two'=>'আপনি এটিকে ফিরিয়ে দিতে সক্ষম হবেন না!',
	'success_three'=>'হ্যাঁ, এটি মুছুন!',
    'success_four'=>'না, বাতিল করুন!',
    'success_five'=>'বাতিল হয়েছে',
    'success_six'=>'আপনার ডেটা নিরাপদ :)',

];

?>