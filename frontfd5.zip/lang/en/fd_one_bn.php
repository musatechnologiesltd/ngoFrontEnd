<?php
return [
    'other_info'=>'অন্যান্য নথি',

];


?>
