<?php
return [
    'submit'=>'NGO Registration Final Submit',
'last'=>'Once you complete all the steps. You will submit the ngo registration form',
    'reg_sub'=>'Registration Submit',
    'reg_sub1'=>'Renew Submit',
    'ff'=>'NGO Registration Final Submission ',
    'll'=>'Last Update File',
    'fe'=>'Features',
    'doc'=>'Document',
    'nid_image'=>'Image & NID Submit',
    'member_info'=>'Members Info',
    'status'=>'Status ',
    'action'=>'Action ',
    'e_check'=>'Eligibility Check ',
    't_check'=>'Terms & Condition',
    'f_fd'=>'FD01 Form Fill up',
    'f_fd_s'=>'FD01 Form Submit',
    'fd_eight'=>'Form 08 Fill up & Date Submit',

];

?>
