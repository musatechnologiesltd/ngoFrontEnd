<?php
return [


    'managesetting'=>'Manage Setting',
    'aboutsetting'=>'About Setting ',
    'passwordsetting'=>'Password Setting',
    'about'=>'About ',
    'address'=>'Address',
    'oldpassword'=>'Old Password',
    'newpassword'=>'New Password',
    'confirmpassword'=>'Confirm Password',
    'editProfile'=>'Edit Your Profile',
    'profile'=>'Profile',
    'Admininfo'=>'Admin Information',
       

     




];

?>