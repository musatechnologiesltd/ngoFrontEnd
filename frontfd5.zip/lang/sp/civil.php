<?php
return [
    'adinfo1' => 'LIST OF NAMES OF GENERAL MEMBERS OF THE ORGANIZATION',
  'adinfo' => 'Administrative information',
  'add' => 'Add',
  'submit' => 'Submit',
  'update'=>'Update',
  'select'=>'--Please Select--',


];


?>
