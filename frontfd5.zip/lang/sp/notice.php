<?php
return [

     'noticeforadmin'=>'Notice For Admin',
     'noticehistory'=>'Notice History',
     'sendnotice'=>'Send Notice',
     'subject'=>'Subject',
     'from'=>'From',
     'view'=>'Viewed',
     'not_Viewd'=>'Not Viewed',
     'status'=>'Status',
     'allnotice'=>'All Notice',
     'fill'=>'Please fill the form carefully',
     'noticebangla'=>'Notice Subject(Bangla)',
     'selectad'=>'Select Admin',
     'des'=>'Notice Description(Bangla)',
     'noti'=>'Notification',
     'viewall'=>'View All',


	];

?>