<?php
return [


    'permissionlist'=>'Permission List',
    'addper'=>'Add Permission Name',
    'pername'=>'Permission Name',
    'per'=>'Permission ',
    'groupname'=>'Group Name',
    'button'=>'Button ',
    'name'=>'Name',
     'addm'=>'Add More',
       'updatep'=>'Update Permission',

     




];

?>