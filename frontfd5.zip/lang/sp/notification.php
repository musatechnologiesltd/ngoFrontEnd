<?php
return [


	'success_one'=>'Are you sure?',
	'success_two'=>'You will not be able to revert this!',
	'success_three'=>'Yes, delete it!',
    'success_four'=>'No, cancel!',
    'success_five'=>'Cancelled',
    'success_six'=>'Your data is safe :)',

     




];

?>