<?php
return [


    'fd2'=>'FD-2 Form',
    'fd3'=>'FD-3 Form',
    'fd6'=>'FD-6 Form',
    'fd7'=>'FD-7 Form',
    'fc1'=>'FC-1 Form',
    'fc2'=>'FC-2 Form',
    'fd5'=>'FD-5 Form',
    'fd09form'=>'FD 09 Form',
    'fd09formone'=>'FD-9.1 (Work Permit)',
    'nvisa'=>'FD-9 Form',
    'm3'=>'Registration Renew',
    'm2'=>'Ngo Name Change',
    'm1'=>'Dashboard',
    'l'=>'Logout',
    'ar'=>'Application for renewal of registration',
];


?>
