<div class="card mb-3">
                                    <div class="card-header">
                                        গঠনতন্ত্র পরিবর্তন ফি বাবদ-১৩,০০০/ (তের হাজার) টাকার (কোড নং-১-০৩২৩-০০০০- ১৮৩৬) চালানের মূলকপি এবং ১৫% ভ্যাট (কোড নং - ১-১১৩৩ -০০৩৫ - ০৩১১) প্রদানপূর্বক চালানের মূলকপিসহ

                                        <br><span class="text-light" style="font-size: 12px;">(Maximum 500 KB)</span>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-6">
                                                <input class="form-control" data-parsley-required accept=".pdf" name="primary_portal[]" type="file" id="foreignNameChange11">
                                                <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange11_text"></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>


<b>গঠনতন্ত্র পরিবর্তন /অনুমোদনের জন্য প্রয়োজনীয় কাগজপত্র: </b>


<div class="mb-3">
    <label class="form-label" for="">
        প্রাথমিক নিবন্ধনকারী কতৃপক্ষের অনুমোদিতো গঠনতন্ত্রের সত্যায়িত কপি  <span class="text-danger">*</span>

        <br><span class="text-danger" style="font-size: 12px;">(Maximum 5 MB)</span>
     </label>
    <input class="form-control" name="primary_portal[]" data-parsley-required accept=".pdf" type="file" id="foreignNameChange12">
    <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange12_text"></p>
</div>

<div class="mb-3">
    <label class="form-label" for="">
        সংস্থার চেয়ারম্যান ও সেক্রেটারি কর্তৃক যৌথ স্বাক্ষরিত গঠনতন্ত্র পরিচ্ছন্ন কপি <span class="text-danger">*</span>

        <br><span class="text-danger" style="font-size: 12px;">(Maximum 5 MB)</span>
    </label>
    <input class="form-control" name="primary_portal[]" data-parsley-required accept=".pdf" type="file" id="foreignNameChange13">
    <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange13_text"></p>
</div>

<div class="mb-3">
    <label class="form-label" for="">
        গঠনতন্ত্রের কোন ধারা, উপধারা পরিবর্তন ফি জমা প্রদানের চালানের মূলকপি   <span class="text-danger">*</span>

        <br><span class="text-danger" style="font-size: 12px;">(Maximum 500 KB)</span>
    </label>
    <input class="form-control" name="primary_portal[]" data-parsley-required accept=".pdf" type="file" id="foreignNameChange14">
    <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange14_text"></p>
</div>

<div class="mb-3">
    <label class="form-label" for="">
        গঠনতন্ত্রের কোন ধারা, উপধারা পরিবর্তন ও সংযোজনের বিষয়ে সাধারণ সভার কার্যবিবরণীর সত্যায়িত কপি   <span class="text-danger">*</span>
        <br><span class="text-danger" style="font-size: 12px;">(Maximum 2 MB)</span>
    </label>
    <input class="form-control" name="primary_portal[]" data-parsley-required accept=".pdf" type="file" id="foreignNameChange15">
    <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange15_text"></p>
</div>

<div class="mb-3">
    <label class="form-label" for="">
        পূর্ব গঠনতন্ত্র ও বর্তমান গঠনতন্ত্রের তুলনামূলক বিবরণী (প্রতি পাতায় সভাপতি ও সম্পাদকের যৌথ স্বাক্ষরসহ <span class="text-danger">*</span>
        <br><span class="text-danger" style="font-size: 12px;">(Maximum 2 MB)</span>
    </label>
    <input class="form-control" name="primary_portal[]" data-parsley-required accept=".pdf" type="file" id="foreignNameChange16">
    <p class="text-danger mt-2" style="font-size:12px;" id="foreignNameChange16_text"></p>
</div>
